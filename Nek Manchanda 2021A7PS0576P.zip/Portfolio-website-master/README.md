# Portfolio-website


Made using HTML5, CSS3, JavaScript.

Recording of form responses is done to the Google Sheets via deployment through Apps Script

contact form responses - https://docs.google.com/spreadsheets/d/1NvpTAnxEoFT-iEOm0vvF3SVk0lWdl0164RgdBnsXHss/edit#gid=0

discussion form responses - https://docs.google.com/spreadsheets/d/1NvpTAnxEoFT-iEOm0vvF3SVk0lWdl0164RgdBnsXHss/edit#gid=0

